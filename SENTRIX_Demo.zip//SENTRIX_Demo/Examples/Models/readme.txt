All Example models are in R2011a '.mdl' format and can be used in Simulink R2011a
(version 7.12) and all later version.